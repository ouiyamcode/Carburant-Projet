package org.isen.projet.carburant.model

import org.isen.projet.carburant.data.impl.SourceJson
import org.isen.projet.carburant.data.impl.SourceXml
import com.github.kittinunf.fuel.httpGet
import com.github.kittinunf.result.Result
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import kotlinx.coroutines.*
import org.apache.logging.log4j.LogManager
import org.apache.logging.log4j.Logger
import java.beans.PropertyChangeListener
import java.beans.PropertyChangeSupport
import java.net.URLEncoder
import kotlin.properties.Delegates

class CarburantModel {
    private val pcs = PropertyChangeSupport(this)
    private val dataSourceJson = SourceJson()
    private val dataSourceXml = SourceXml()
    private val cacheGeocoding = mutableMapOf<String, Pair<String, String>>() // Cache pour éviter trop de requêtes Nominatim
    private val objectMapper = jacksonObjectMapper() // ✅ Utilisation de Jackson pour parser JSON
    private val logger: Logger = LogManager.getLogger(CarburantModel::class.java)

    var stations: List<Station> by Delegates.observable(emptyList()) { property, oldValue, newValue ->
        pcs.firePropertyChange(property.name, oldValue, newValue)
        LeafletService.generateMapHtml(newValue)
    }

    fun updateStations(newStations: List<Station>) {
        stations = newStations
    }

    fun addObserver(l: PropertyChangeListener) {
        pcs.addPropertyChangeListener(l)
    }

    /**
     * 📡 **Méthode pour récupérer les stations-service selon la source sélectionnée**
     */
    fun fetchStations(
        city: String,
        useJsonSource: Boolean,
        fuelType: String? = null,
        hasToilets: Boolean = false,
        hasAirPump: Boolean = false,
        hasFoodShop: Boolean = false
    ) {
        val dataSource = if (useJsonSource) dataSourceJson else dataSourceXml
        val sourceName = if (useJsonSource) "📡 Source Principale (JSON)" else "📡 Source Secondaire (XML)"
        logger.info("📍 Chargement des stations pour ${city}... Nombre de stations récupérées : ${stations.size}")

        logger.info("$sourceName : Recherche en cours pour la ville : $city...")

        GlobalScope.launch(Dispatchers.IO) {
            val stations = dataSource.fetchDataForCity(city, fuelType, hasToilets, hasAirPump, hasFoodShop)

            // 🔥 Enrichissement des coordonnées avec Nominatim si nécessaire
            val enrichedStations = stations.map { station ->
                if (station.latitude == "0.0" || station.longitude == "0.0") {
                    fetchCoordinatesFromNominatim(station) ?: station
                } else {
                    station
                }
            }

            withContext(Dispatchers.Default) {
                updateStations(enrichedStations)
                logger.info("✅ Modèle mis à jour avec ${enrichedStations.size} stations pour $city depuis $sourceName !")
            }
        }
    }

    /**
     * 🌍 **Méthode pour récupérer les coordonnées manquantes avec Nominatim**
     */
    private fun fetchCoordinatesFromNominatim(station: Station): Station? {
        val fullAddress = "${station.adresse}, ${station.codePostal}, ${station.ville}, FRANCE"

        // 📌 Vérifie si les coordonnées sont déjà en cache
        if (cacheGeocoding.containsKey(fullAddress)) {
            val (lat, lon) = cacheGeocoding[fullAddress]!!
            return station.copy(latitude = lat, longitude = lon)
        }

        val encodedAddress = URLEncoder.encode(fullAddress, "UTF-8")
        val url = "https://nominatim.openstreetmap.org/search?format=json&q=$encodedAddress"

        return try {
            val (_, _, result) = url.httpGet().responseString()
            when (result) {
                is Result.Success -> {
                    val jsonData = result.get()

                    // ✅ Correction de `readValue` en spécifiant le type attendu
                    val geoResults: List<Map<String, Any>> = objectMapper.readValue(jsonData)

                    if (geoResults.isNotEmpty()) {
                        val firstResult = geoResults[0]
                        val lat = firstResult["lat"]?.toString() ?: return null
                        val lon = firstResult["lon"]?.toString() ?: return null

                        // 📌 Stockage en cache pour éviter les requêtes multiples
                        cacheGeocoding[fullAddress] = Pair(lat, lon)

                        logger.info("📍 Géocodage réussi: $fullAddress -> ($lat, $lon)")
                        station.copy(latitude = lat, longitude = lon)
                    } else {
                        logger.warn("❌ Aucun résultat pour $fullAddress")
                        null
                    }
                }
                is Result.Failure -> {
                    logger.error("❌ Erreur HTTP lors de la requête Nominatim: ${result.error.message}")
                    null
                }
            }
        } catch (e: Exception) {
            logger.error("❌ Erreur lors de la requête Nominatim: ${e.message}")
            null
        }
    }
    /**
     * 🌍 **Géocodage d'une ville avec Nominatim**
     * @param ville Nom de la ville à géocoder
     * @return Latitude et Longitude sous forme de Pair<String, String>, ou null si erreur
     */
    fun geocodeVille(ville: String): Pair<String, String>? {
        // Vérification du cache pour éviter les requêtes répétées
        if (cacheGeocoding.containsKey(ville)) {
            return cacheGeocoding[ville]
        }

        val encodedVille = URLEncoder.encode(ville, "UTF-8")
        val url = "https://nominatim.openstreetmap.org/search?format=json&q=$encodedVille&countrycodes=FR"

        return try {
            val (_, _, result) = url.httpGet().responseString()
            when (result) {
                is Result.Success -> {
                    val jsonData = result.get()
                    val geoResults: List<Map<String, Any>> = objectMapper.readValue(jsonData)

                    if (geoResults.isNotEmpty()) {
                        val firstResult = geoResults[0]
                        val lat = firstResult["lat"]?.toString() ?: return null
                        val lon = firstResult["lon"]?.toString() ?: return null

                        // Stocker en cache
                        cacheGeocoding[ville] = Pair(lat, lon)
                        logger.info("📍 Géocodage réussi: $ville -> ($lat, $lon)")

                        Pair(lat, lon)
                    } else {
                        logger.warn("❌ Aucun résultat pour $ville")
                        null
                    }
                }
                is Result.Failure -> {
                    logger.error("❌ Erreur HTTP lors de la requête Nominatim: ${result.error.message}")
                    null
                }
            }
        } catch (e: Exception) {
            logger.error("❌ Erreur lors de la requête Nominatim: ${e.message}")
            null
        }
    }
    /**
     * 🚗 **Calculer l'itinéraire entre deux villes avec OpenRouteService**
     * @param departCoord Coordonnées (latitude, longitude) de la ville de départ
     * @param arriveeCoord Coordonnées (latitude, longitude) de la ville d’arrivée
     * @return Liste de points GPS formant le trajet (ou null en cas d'erreur)
     */
    fun calculerItineraire(departCoord: Pair<String, String>, arriveeCoord: Pair<String, String>): List<Pair<Double, Double>>? {
        val apiKey = "5b3ce3597851110001cf6248b38f36766e024b708ee298402a9ade37" // Remplacez par votre clé API ORS
        val url = "https://api.openrouteservice.org/v2/directions/driving-car?api_key=$apiKey" +
                "&start=${departCoord.second},${departCoord.first}&end=${arriveeCoord.second},${arriveeCoord.first}"

// 🔍 Afficher l’URL pour vérification
        logger.info("🌍 Requête OpenRouteService : $url")




        return try {
            val (_, _, result) = url.httpGet().responseString()
            logger.info("🔎 Réponse OpenRouteService : ${result.get()}")
            when (result) {
                is Result.Success -> {
                    val jsonData = result.get()
                    val response: Map<String, Any> = objectMapper.readValue(jsonData)

                    val routes = response["features"] as? List<Map<String, Any>>
                    if (!routes.isNullOrEmpty()) {
                        val geometry = routes[0]["geometry"] as? Map<String, Any>
                        val coordinates = geometry?.get("coordinates") as? List<List<Double>>

                        if (coordinates != null) {
                            val itineraire = coordinates.map { Pair(it[1], it[0]) } // Inverser lon/lat -> lat/lon
                            logger.info("✅ Itinéraire trouvé (${itineraire.size} points)")
                            return itineraire
                        } else {
                            logger.warn("❌ Aucune coordonnée trouvée dans la réponse de l'API")
                            return null
                        }
                    } else {
                        logger.warn("❌ Aucune route trouvée dans la réponse de l'API")
                        return null
                    }

                }
                is Result.Failure -> {
                    logger.error("❌ Erreur HTTP lors de la requête ORS: ${result.error.message}")
                    null
                }
            }
        } catch (e: Exception) {
            logger.error("❌ Erreur lors de la requête OpenRouteService: ${e.message}")
            null
        }
    }

    /**
     * 🔍 **Décoder un polyline encodé (format OpenRouteService) en liste de coordonnées**
     * @param encoded Polyline encodé
     * @return Liste de points (latitude, longitude)
     */
    fun decodePolyline(encoded: String): List<Pair<Double, Double>> {
        val poly = mutableListOf<Pair<Double, Double>>()
        var index = 0
        val len = encoded.length
        var lat = 0
        var lon = 0

        while (index < len) {
            var b: Int
            var shift = 0
            var result = 0
            do {
                b = encoded[index++].code - 63
                result = result or ((b and 0x1F) shl shift)
                shift += 5
            } while (b >= 0x20)
            val deltaLat = if (result and 1 != 0) (result shr 1).inv() else (result shr 1)
            lat += deltaLat

            shift = 0
            result = 0
            do {
                b = encoded[index++].code - 63
                result = result or ((b and 0x1F) shl shift)
                shift += 5
            } while (b >= 0x20)
            val deltaLon = if (result and 1 != 0) (result shr 1).inv() else (result shr 1)
            lon += deltaLon

            poly.add(Pair(lat / 1E5, lon / 1E5))
        }
        return poly
    }
    /**
     * ⛽ **Filtrer les stations-service situées à proximité d’un itinéraire**
     * @param itineraire Liste des points GPS de l’itinéraire
     * @return Liste des stations-service proches de l’itinéraire
     */
    fun stationsSurItineraire(itineraire: List<Pair<Double, Double>>, rayonKm: Double = 5.0): List<Station> {
        logger.info("📍 Nombre total de stations disponibles : ${stations.size}")

        logger.info("🔎 Recherche des stations sur l’itinéraire (${itineraire.size} points)...")

        // Récupérer toutes les stations disponibles (depuis la source JSON/XML)
        val toutesStations = stations

        // Liste pour stocker les stations proches du trajet
        val stationsProches = mutableListOf<Station>()

        // Vérifier chaque station pour voir si elle est proche d'un point de l'itinéraire
        toutesStations.forEach { station ->
            val stationCoord = Pair(station.latitude.toDoubleOrNull() ?: 0.0, station.longitude.toDoubleOrNull() ?: 0.0)

            // Vérifier si la station est à proximité du trajet
            if (stationCoord.first != 0.0 && stationCoord.second != 0.0) {
                for (point in itineraire) {
                    val distance = distanceGPS(stationCoord, point)

                    // 📏 Afficher la distance de chaque station par rapport au trajet
                    logger.info("📏 Distance entre ${station.ville} et un point du trajet: $distance km")


                    logger.info("📏 Distance entre ${station.ville} et le trajet: $distance km")

                    if (distance <= rayonKm) {
                        stationsProches.add(station)
                        break // Pas besoin de tester tous les points de l’itinéraire
                    }
                }
            }
        }

        logger.info("✅ ${stationsProches.size} stations trouvées sur l'itinéraire.")
        return stationsProches
    }

    /**
     * 📏 **Calcul de la distance entre deux points GPS (Haversine)**
     * @param coord1 Coordonnées (latitude, longitude) du premier point
     * @param coord2 Coordonnées (latitude, longitude) du second point
     * @return Distance en kilomètres
     */
    private fun distanceGPS(coord1: Pair<Double, Double>, coord2: Pair<Double, Double>): Double {
        val R = 6371.0 // Rayon de la Terre en km
        val lat1 = Math.toRadians(coord1.first)
        val lon1 = Math.toRadians(coord1.second)
        val lat2 = Math.toRadians(coord2.first)
        val lon2 = Math.toRadians(coord2.second)

        val dlat = lat2 - lat1
        val dlon = lon2 - lon1

        val a = Math.sin(dlat / 2) * Math.sin(dlat / 2) +
                Math.cos(lat1) * Math.cos(lat2) *
                Math.sin(dlon / 2) * Math.sin(dlon / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))

        return R * c
    }



}
