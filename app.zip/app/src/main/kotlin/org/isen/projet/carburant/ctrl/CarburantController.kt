package org.isen.projet.carburant.ctrl

import kotlinx.coroutines.*
import org.isen.projet.carburant.model.CarburantModel
import org.isen.projet.carburant.view.ICarburantView

class CarburantController(private val model: CarburantModel) {
    private val views = mutableListOf<ICarburantView>()

    fun registerView(view: ICarburantView) {
        model.addObserver(view)
        views.add(view)
    }

    fun displayAll() {
        views.forEach { it.display() }
    }
    /**
     * 🚗 **Recherche un itinéraire entre deux villes et affiche les stations-service sur le trajet**
     */
    fun rechercherItineraire(villeDepart: String, villeArrivee: String) {
        // 1️⃣ Géocoder les villes
        val coordDepart = model.geocodeVille(villeDepart)
        val coordArrivee = model.geocodeVille(villeArrivee)

        if (coordDepart == null || coordArrivee == null) {
            println("❌ Impossible de géocoder une des villes ($villeDepart, $villeArrivee)")
            return
        }

        // 2️⃣ Calculer l’itinéraire
        val itineraire = model.calculerItineraire(coordDepart, coordArrivee)
        if (itineraire.isNullOrEmpty()) {
            println("❌ Aucun itinéraire trouvé entre $villeDepart et $villeArrivee")
            return
        }

        // 3️⃣ Charger les stations et mettre à jour la carte après récupération
        runBlocking {
            launch(Dispatchers.IO) {
                model.fetchStations(villeDepart, true) // 🔥 Lancer le chargement des stations
                delay(2000) // ⏳ Attendre un peu pour être sûr que les stations sont chargées

                val stationsSurItineraire = model.stationsSurItineraire(itineraire, 100.0)

                println("✅ ${stationsSurItineraire.size} stations trouvées sur l'itinéraire.")

                // 4️⃣ Mettre à jour la Vue avec l’itinéraire et les stations
                views.forEach { view ->
                    if (view is org.isen.projet.carburant.view.impl.CarburantMapView) {
                        view.updateRouteOnMap(itineraire)
                        view.updateStationsOnMap(stationsSurItineraire)
                    }
                }
            }
        }

    }


    /**
     * 🌍 **Appelle directement le modèle pour récupérer les stations**
     */
    fun updateModelForCityWithSource(
        city: String,
        useJsonSource: Boolean,
        fuelType: String? = null,
        hasToilets: Boolean = false,
        hasAirPump: Boolean = false,
        hasFoodShop: Boolean = false
    ) {
        model.fetchStations(city, useJsonSource, fuelType, hasToilets, hasAirPump, hasFoodShop)
    }

}










